/**
 * 
 */
package teamproject.publisher.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import teamproject.common.Criteria;
import teamproject.publisher.service.PublisherService;
import teamproject.publisher.service.PublisherVO;

/**
 * @author user
 *
 */
@Service
public class PublisherServiceImpl implements PublisherService{
	@Autowired
	PublisherMapper publisherMapper;
//	전체조회
	@Override
	public List<?> selectPublisherList(Criteria criteria) {
		// TODO Auto-generated method stub
		return publisherMapper.selectPublisherList(criteria);
	}
//	총 개수 구하기
	@Override
	public int selectPublisherListTotCnt(Criteria criteria) {
		// TODO Auto-generated method stub
		return publisherMapper.selectPublisherListTotCnt(criteria);
	}
//	추가하기
	@Override
	public int insert(PublisherVO publisherVO) {
		// TODO Auto-generated method stub
		return publisherMapper.insert(publisherVO);
	}
// 상세조회
	@Override
	public PublisherVO selectPublisher(String publisherId) {
		// TODO Auto-generated method stub
		return publisherMapper.selectPublisher(publisherId);
	}
//	수정하기
	@Override
	public int update(PublisherVO publisherVO) {
		// TODO Auto-generated method stub
		return publisherMapper.update(publisherVO);
	}
//	삭제하기
	@Override
	public int delete(PublisherVO publisherVO) {
		// TODO Auto-generated method stub
		return publisherMapper.delete(publisherVO);
	}
	
}
