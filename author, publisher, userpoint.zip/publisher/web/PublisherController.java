/**
 * 
 */
package teamproject.publisher.web;

/**
 * @author user
 *
 */
public class PublisherController {

}
