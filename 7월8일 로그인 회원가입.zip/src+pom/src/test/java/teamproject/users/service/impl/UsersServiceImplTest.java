package teamproject.users.service.impl;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import lombok.extern.log4j.Log4j2;
import teamproject.users.service.UsersService;
import teamproject.users.service.UsersVO;
@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = {
		"classpath:/egovframework/spring/context-aspect.xml",
	    "classpath:/egovframework/spring/context-common.xml",
	    "classpath:/egovframework/spring/context-datasource.xml",
	    "classpath:/egovframework/spring/context-idgen.xml",
	    "classpath:/egovframework/spring/context-mapper.xml",
	    "classpath:/egovframework/spring/context-sqlMap.xml",
	    "classpath:/egovframework/spring/context-transaction.xml"
	})
@Log4j2
class UsersServiceImplTest {
	@Autowired
	UsersService usersService;
	@Test
	void testRegister()throws Exception {
//		1) 테스트 조건: DeptVO(dno,dname,loc)
		UsersVO usersVO=new UsersVO();
		usersVO.setUserId("www");
		usersVO.setUserEmail("www");
		usersVO.setUserPw("ww");
		usersVO.setUserName("www");
		usersVO.setJoinDate("2025-07-08");
		usersVO.setUserIsDeleted("n");
		usersVO.setUserDeletedAt("2025-07-05");
		usersVO.setUserRole("a");
//		2) 실제 메소드실행
		usersService.register(usersVO);
	}

}
